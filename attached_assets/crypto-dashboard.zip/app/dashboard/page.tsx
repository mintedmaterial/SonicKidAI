"use client"

import { useEffect, useState } from "react"
import { DashboardLayout } from "@/components/dashboard-layout"
import { DashboardFeed } from "@/components/dashboard-feed"
import { TrendingUp, DollarSign, Newspaper, Activity } from "lucide-react"
import { Card } from "@/components/ui/card"
import { useQuery } from "@tanstack/react-query"

export default function DashboardPage() {
  const [mounted, setMounted] = useState(false)

  // Only render the component after it has mounted
  // This prevents hydration issues
  useEffect(() => {
    setMounted(true)
  }, [])

  // Query for Sonic TVL data
  const { data: sonicData, isLoading: sonicLoading } = useQuery({
    queryKey: ["/api/market/sonic"],
    refetchInterval: 300000, // Refresh every 5 minutes
    suspense: false, // Disable suspense to prevent insertion effect issues
    useErrorBoundary: false, // Disable error boundary to prevent insertion effect issues
    enabled: mounted, // Only run query after component has mounted
  })

  // Query for sentiment data from our Hugging Face integration
  const { data: sentimentData, isLoading: sentimentLoading } = useQuery({
    queryKey: ["/api/market/sentiment"],
    refetchInterval: 60000, // Refresh every minute
    suspense: false,
    useErrorBoundary: false,
    enabled: mounted,
  })

  // Query for market news
  const { data: newsData, isLoading: newsLoading } = useQuery({
    queryKey: ["/api/market/news"],
    refetchInterval: 60000, // Refresh every minute
    suspense: false,
    useErrorBoundary: false,
    enabled: mounted,
  })

  if (!mounted) {
    return <div className="min-h-screen bg-background"></div>
  }

  return (
    <DashboardLayout>
      <div className="mb-6">
        <h1 className="text-2xl font-bold">ZerePy Dashboard</h1>
        <p className="text-muted-foreground">Market intelligence and agent activity</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
        {/* Sonic TVL Card */}
        <Card className="p-4 bg-background/50 backdrop-blur border border-primary/20 shadow-lg shadow-primary/5">
          <h2 className="text-lg font-semibold flex items-center gap-2 mb-4">
            <DollarSign className="h-5 w-5 text-primary" />
            Sonic TVL
          </h2>
          <div>
            {sonicLoading ? (
              <p>Loading TVL data...</p>
            ) : (
              <>
                <p className="text-3xl font-bold">${(sonicData?.tvl || 0).toLocaleString()}</p>
                <div
                  className={`flex items-center gap-1 mt-2 ${
                    (sonicData?.tvlChange24h || 0) >= 0 ? "text-green-500" : "text-red-500"
                  }`}
                >
                  {(sonicData?.tvlChange24h || 0) >= 0 ? (
                    <TrendingUp className="h-4 w-4" />
                  ) : (
                    <TrendingUp className="h-4 w-4 rotate-180" />
                  )}
                  <span>{(sonicData?.tvlChange24h || 0).toFixed(2)}%</span>
                </div>
              </>
            )}
          </div>
        </Card>

        {/* Market Sentiment Card */}
        <Card className="p-4 bg-background/50 backdrop-blur border border-primary/20 shadow-lg shadow-primary/5">
          <h2 className="text-lg font-semibold flex items-center gap-2 mb-4">
            <Activity className="h-5 w-5 text-primary" />
            Market Sentiment
          </h2>
          <div>
            {sentimentLoading ? (
              <p>Analyzing market sentiment...</p>
            ) : (
              <>
                <p className="text-xl font-bold mb-2">{sentimentData?.sentiment || "Neutral"}</p>
                <p className="text-sm text-muted-foreground">Confidence: {sentimentData?.confidence || 0}%</p>
                <div className="mt-4">
                  <h3 className="text-sm font-medium mb-2">Trending Topics</h3>
                  {sentimentData?.trending?.map((topic: any, index: number) => (
                    <div key={index} className="text-sm flex items-center justify-between py-1">
                      <span className="font-medium">
                        #{index + 1} {topic.topic}
                      </span>
                      <span className="text-muted-foreground">{topic.volume?.toLocaleString()} mentions</span>
                    </div>
                  ))}
                </div>
              </>
            )}
          </div>
        </Card>
      </div>

      {/* Market News Section */}
      <Card className="p-4 mb-6 bg-background/50 backdrop-blur border border-primary/20 shadow-lg shadow-primary/5">
        <h2 className="text-lg font-semibold flex items-center gap-2 mb-4">
          <Newspaper className="h-5 w-5 text-primary" />
          Latest Market News
        </h2>
        <div className="space-y-2">
          {newsLoading ? (
            <p>Loading news...</p>
          ) : (
            newsData?.articles?.slice(0, 5).map((article: any, index: number) => (
              <div key={index} className="border-b border-primary/10 last:border-0 pb-2">
                <p className="font-medium">{article.title}</p>
                <p className="text-sm text-muted-foreground">
                  {article.source} - {article.time}
                </p>
              </div>
            ))
          )}
        </div>
      </Card>

      {/* Agent Activity Feed */}
      <DashboardFeed />
    </DashboardLayout>
  )
}

