"use client"

import { QueryClient, QueryClientProvider } from "@tanstack/react-query"
import { useState, type ReactNode } from "react"

export function Providers({ children }: { children: ReactNode }) {
  // Create a new QueryClient instance with improved error handling
  const [queryClient] = useState(
    () =>
      new QueryClient({
        defaultOptions: {
          queries: {
            // Disable suspense by default to prevent insertion effect issues
            suspense: false,
            // Disable error boundary to handle errors manually
            useErrorBoundary: false,
            // Stale time of 5 minutes
            staleTime: 5 * 60 * 1000,
            // Retry failed queries 1 time
            retry: 1,
            // Add a default error handler to prevent unhandled rejections
            onError: (error) => {
              console.error("Query error:", error)
            },
          },
          mutations: {
            // Add error handling for mutations as well
            onError: (error) => {
              console.error("Mutation error:", error)
            },
          },
        },
      }),
  )

  return <QueryClientProvider client={queryClient}>{children}</QueryClientProvider>
}

