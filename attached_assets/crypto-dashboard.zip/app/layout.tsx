import "@/styles/globals.css"
import { Inter } from "next/font/google"
import type React from "react"
import { Providers } from "./providers"

const inter = Inter({ subsets: ["latin"] })

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <head>
        <title>SonicKid AI - Crypto Intelligence</title>
        <meta name="description" content="Real-time crypto market data and analytics powered by SonicKid AI" />
      </head>
      <body className={inter.className}>
        <Providers>{children}</Providers>
      </body>
    </html>
  )
}



import './globals.css'

export const metadata = {
      generator: 'v0.dev'
    };
