"use client"

import { useEffect, useState } from "react"
import { DashboardLayout } from "@/components/dashboard-layout"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { TvlChart } from "@/components/crypto/tvl-chart"
import { TokenPairs } from "@/components/crypto/token-pairs"
import { LiquidityPools } from "@/components/crypto/liquidity-pools"
import { CryptoNews } from "@/components/crypto/crypto-news"
import { HotNfts } from "@/components/crypto/hot-nfts"
import { TwitterFeed } from "@/components/crypto/twitter-feed"
import { PriceCards } from "@/components/crypto/price-cards"
import { BarChart3, Coins, DollarSign, LineChart, Newspaper, Palette, Twitter } from "lucide-react"
import { ErrorBoundary } from "@/components/error-boundary"

export default function CryptoPage() {
  const [mounted, setMounted] = useState(false)

  // Only render the component after it has mounted
  // This prevents hydration issues
  useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted) {
    return <div className="min-h-screen bg-background"></div>
  }

  return (
    <DashboardLayout>
      <div className="mb-6">
        <h1 className="text-2xl font-bold">Crypto Dashboard</h1>
        <p className="text-muted-foreground">Real-time crypto market data and analytics</p>
      </div>

      {/* Price Cards */}
      <ErrorBoundary fallback={<div className="p-4 text-red-500">Failed to load price data</div>}>
        <PriceCards />
      </ErrorBoundary>

      {/* Main Content Tabs */}
      <Tabs defaultValue="overview" className="mt-6">
        <TabsList className="grid grid-cols-6 md:w-fit">
          <TabsTrigger value="overview" className="flex items-center gap-2">
            <BarChart3 className="h-4 w-4" />
            <span className="hidden sm:inline">Overview</span>
          </TabsTrigger>
          <TabsTrigger value="tvl" className="flex items-center gap-2">
            <DollarSign className="h-4 w-4" />
            <span className="hidden sm:inline">TVL</span>
          </TabsTrigger>
          <TabsTrigger value="pairs" className="flex items-center gap-2">
            <Coins className="h-4 w-4" />
            <span className="hidden sm:inline">Pairs</span>
          </TabsTrigger>
          <TabsTrigger value="news" className="flex items-center gap-2">
            <Newspaper className="h-4 w-4" />
            <span className="hidden sm:inline">News</span>
          </TabsTrigger>
          <TabsTrigger value="nfts" className="flex items-center gap-2">
            <Palette className="h-4 w-4" />
            <span className="hidden sm:inline">NFTs</span>
          </TabsTrigger>
          <TabsTrigger value="social" className="flex items-center gap-2">
            <Twitter className="h-4 w-4" />
            <span className="hidden sm:inline">Social</span>
          </TabsTrigger>
        </TabsList>

        {/* Overview Tab */}
        <TabsContent value="overview" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <ErrorBoundary fallback={<Card className="p-4">Failed to load TVL data</Card>}>
              <Card className="bg-background/50 backdrop-blur border border-primary/20 shadow-lg shadow-primary/5">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <DollarSign className="h-5 w-5 text-primary" />
                    TVL Overview
                  </CardTitle>
                  <CardDescription>Total Value Locked across protocols</CardDescription>
                </CardHeader>
                <CardContent>
                  <TvlChart height={250} />
                </CardContent>
              </Card>
            </ErrorBoundary>

            <ErrorBoundary fallback={<Card className="p-4">Failed to load news data</Card>}>
              <Card className="bg-background/50 backdrop-blur border border-primary/20 shadow-lg shadow-primary/5">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Newspaper className="h-5 w-5 text-primary" />
                    Latest News
                  </CardTitle>
                  <CardDescription>Recent crypto news and updates</CardDescription>
                </CardHeader>
                <CardContent>
                  <CryptoNews limit={5} />
                </CardContent>
              </Card>
            </ErrorBoundary>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <ErrorBoundary fallback={<Card className="p-4">Failed to load token pairs data</Card>}>
              <Card className="bg-background/50 backdrop-blur border border-primary/20 shadow-lg shadow-primary/5">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Coins className="h-5 w-5 text-primary" />
                    Top Pairs
                  </CardTitle>
                  <CardDescription>Most active trading pairs</CardDescription>
                </CardHeader>
                <CardContent>
                  <TokenPairs limit={5} />
                </CardContent>
              </Card>
            </ErrorBoundary>

            <ErrorBoundary fallback={<Card className="p-4">Failed to load Twitter data</Card>}>
              <Card className="bg-background/50 backdrop-blur border border-primary/20 shadow-lg shadow-primary/5">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Twitter className="h-5 w-5 text-primary" />
                    Twitter Feed
                  </CardTitle>
                  <CardDescription>Latest crypto tweets</CardDescription>
                </CardHeader>
                <CardContent>
                  <TwitterFeed limit={5} />
                </CardContent>
              </Card>
            </ErrorBoundary>
          </div>
        </TabsContent>

        {/* Other tabs with error boundaries */}
        <TabsContent value="tvl">
          <ErrorBoundary fallback={<Card className="p-4">Failed to load TVL data</Card>}>
            <Card className="bg-background/50 backdrop-blur border border-primary/20 shadow-lg shadow-primary/5">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <DollarSign className="h-5 w-5 text-primary" />
                  Total Value Locked (TVL)
                </CardTitle>
                <CardDescription>Detailed TVL data from DeFiLlama</CardDescription>
              </CardHeader>
              <CardContent>
                <TvlChart height={400} />
              </CardContent>
            </Card>
          </ErrorBoundary>
        </TabsContent>

        {/* Pairs Tab */}
        <TabsContent value="pairs">
          <div className="grid grid-cols-1 gap-4">
            <Card className="bg-background/50 backdrop-blur border border-primary/20 shadow-lg shadow-primary/5">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Coins className="h-5 w-5 text-primary" />
                  Token Pairs
                </CardTitle>
                <CardDescription>Trading pairs from DexScreener</CardDescription>
              </CardHeader>
              <CardContent>
                <TokenPairs />
              </CardContent>
            </Card>

            <Card className="bg-background/50 backdrop-blur border border-primary/20 shadow-lg shadow-primary/5">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <LineChart className="h-5 w-5 text-primary" />
                  Liquidity Pools
                </CardTitle>
                <CardDescription>Pools from Equalizer</CardDescription>
              </CardHeader>
              <CardContent>
                <LiquidityPools />
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* News Tab */}
        <TabsContent value="news">
          <Card className="bg-background/50 backdrop-blur border border-primary/20 shadow-lg shadow-primary/5">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Newspaper className="h-5 w-5 text-primary" />
                Crypto News
              </CardTitle>
              <CardDescription>Latest news from Crypto Panic</CardDescription>
            </CardHeader>
            <CardContent>
              <CryptoNews />
            </CardContent>
          </Card>
        </TabsContent>

        {/* NFTs Tab */}
        <TabsContent value="nfts">
          <Card className="bg-background/50 backdrop-blur border border-primary/20 shadow-lg shadow-primary/5">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Palette className="h-5 w-5 text-primary" />
                Hot NFTs
              </CardTitle>
              <CardDescription>Trending NFTs from PaintSwap</CardDescription>
            </CardHeader>
            <CardContent>
              <HotNfts />
            </CardContent>
          </Card>
        </TabsContent>

        {/* Social Tab */}
        <TabsContent value="social">
          <Card className="bg-background/50 backdrop-blur border border-primary/20 shadow-lg shadow-primary/5">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Twitter className="h-5 w-5 text-primary" />
                Twitter Feed
              </CardTitle>
              <CardDescription>Latest tweets from crypto influencers</CardDescription>
            </CardHeader>
            <CardContent>
              <TwitterFeed />
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </DashboardLayout>
  )
}

