"use client"

import { useEffect, useState } from "react"
import { DashboardLayout } from "@/components/dashboard-layout"
import { MetricsCard } from "@/components/metrics-card"
import { StatsChart } from "@/components/stats-chart"
import { AgentTable } from "@/components/agent-table"
import { DashboardFeed } from "@/components/dashboard-feed"
import { Bot, MessageSquare, Zap, Clock, Users, Database, BarChart3 } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function Page() {
  const [mounted, setMounted] = useState(false)

  // Only render the component after it has mounted
  // This prevents hydration issues
  useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted) {
    return <div className="min-h-screen bg-background"></div>
  }

  return (
    <DashboardLayout>
      <div className="mb-6 flex items-center justify-between">
        <div className="space-y-1">
          <h1 className="text-2xl font-bold">Agent Dashboard</h1>
          <div className="text-sm text-muted-foreground">Real-time monitoring and analytics</div>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <MetricsCard
          title="Active Agents"
          value="2"
          change={{ value: "+1", percentage: "+50%", isPositive: true }}
          icon={<Bot className="h-4 w-4" />}
        />
        <MetricsCard
          title="Total Requests"
          value="2,419"
          change={{ value: "+342", percentage: "+16.5%", isPositive: true }}
          icon={<MessageSquare className="h-4 w-4" />}
        />
        <MetricsCard
          title="Avg. Response Time"
          value="0.9s"
          change={{ value: "-0.2s", percentage: "-18.2%", isPositive: true }}
          icon={<Clock className="h-4 w-4" />}
        />
        <MetricsCard
          title="Active Users"
          value="47"
          change={{ value: "+12", percentage: "+34.3%", isPositive: true }}
          icon={<Users className="h-4 w-4" />}
        />
      </div>

      <div className="mt-6">
        <StatsChart />
      </div>

      <Tabs defaultValue="agents" className="mt-6">
        <TabsList>
          <TabsTrigger value="agents" className="flex items-center gap-2">
            <Bot className="h-4 w-4" />
            Agents
          </TabsTrigger>
          <TabsTrigger value="activity" className="flex items-center gap-2">
            <Zap className="h-4 w-4" />
            Activity
          </TabsTrigger>
          <TabsTrigger value="analytics" className="flex items-center gap-2">
            <BarChart3 className="h-4 w-4" />
            Analytics
          </TabsTrigger>
          <TabsTrigger value="database" className="flex items-center gap-2">
            <Database className="h-4 w-4" />
            Database
          </TabsTrigger>
        </TabsList>
        <TabsContent value="agents" className="mt-4">
          <Card>
            <CardHeader>
              <CardTitle>Agent Status</CardTitle>
            </CardHeader>
            <CardContent>
              <AgentTable />
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="activity" className="mt-4">
          <DashboardFeed />
        </TabsContent>
        <TabsContent value="analytics" className="mt-4">
          <Card>
            <CardHeader>
              <CardTitle>Analytics</CardTitle>
            </CardHeader>
            <CardContent>
              <p>Analytics content will be displayed here.</p>
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="database" className="mt-4">
          <Card>
            <CardHeader>
              <CardTitle>Database Status</CardTitle>
            </CardHeader>
            <CardContent>
              <p>Database status and metrics will be displayed here.</p>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </DashboardLayout>
  )
}

