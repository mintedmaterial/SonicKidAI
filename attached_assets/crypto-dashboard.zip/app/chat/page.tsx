"use client"

import { useEffect, useState } from "react"
import { DashboardLayout } from "@/components/dashboard-layout"
import { ChatBox } from "@/components/chat/ChatBox"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

export default function ChatPage() {
  const [mounted, setMounted] = useState(false)

  // Only render the component after it has mounted
  // This prevents hydration issues
  useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted) {
    return <div className="min-h-screen bg-background"></div>
  }

  return (
    <DashboardLayout>
      <div className="mb-6">
        <h1 className="text-2xl font-bold">Agent Chat Interface</h1>
        <p className="text-muted-foreground">Interact with your AI agents</p>
      </div>

      <Card className="bg-background/50 backdrop-blur border border-primary/20 shadow-lg shadow-primary/5">
        <CardHeader>
          <CardTitle>Chat</CardTitle>
        </CardHeader>
        <CardContent>
          <ChatBox />
        </CardContent>
      </Card>
    </DashboardLayout>
  )
}

