"use client"

import type React from "react"

import { useEffect, useState } from "react"
import { Sidebar } from "@/components/sidebar"
import { cn } from "@/lib/utils"

interface DashboardLayoutProps {
  children: React.ReactNode
  className?: string
}

export function DashboardLayout({ children, className }: DashboardLayoutProps) {
  const [mounted, setMounted] = useState(false)

  // Only render the sidebar after the component has mounted
  // This prevents hydration issues with the routing
  useEffect(() => {
    setMounted(true)
  }, [])

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-background/90">
      {mounted && <Sidebar />}
      <main className={cn("lg:pl-64 transition-all duration-300 ease-in-out", className)}>
        <div className="container mx-auto p-4 lg:p-6">{children}</div>
      </main>
    </div>
  )
}

