"use client"

import { useState } from "react"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Avatar } from "@/components/ui/avatar"
import { ScrollArea } from "@/components/ui/scroll-area"

interface ChatMessage {
  id: string
  sender: "user" | "agent"
  message: string
}

export function ChatBox() {
  const [messages, setMessages] = useState<ChatMessage[]>([])
  const [input, setInput] = useState("")

  const handleSendMessage = () => {
    if (input.trim() !== "") {
      const newMessage: ChatMessage = {
        id: Date.now().toString(),
        sender: "user",
        message: input,
      }
      setMessages([...messages, newMessage])
      setInput("")

      // Simulate agent response (replace with actual agent logic)
      setTimeout(() => {
        const agentMessage: ChatMessage = {
          id: Date.now().toString(),
          sender: "agent",
          message: `Agent response to: ${input}`,
        }
        setMessages([...messages, agentMessage])
      }, 500)
    }
  }

  return (
    <div className="flex flex-col h-[500px]">
      <ScrollArea className="flex-grow p-4">
        <div className="space-y-4">
          {messages.map((message) => (
            <div
              key={message.id}
              className={`flex items-start gap-2 ${message.sender === "user" ? "justify-end" : ""}`}
            >
              {message.sender === "agent" && (
                <Avatar className="h-8 w-8">
                  <img src="/placeholder.svg?height=32&width=32" alt="Agent" />
                </Avatar>
              )}
              <div
                className={`rounded-lg p-2 ${
                  message.sender === "user"
                    ? "bg-primary text-primary-foreground"
                    : "bg-secondary text-secondary-foreground"
                }`}
              >
                {message.message}
              </div>
            </div>
          ))}
        </div>
      </ScrollArea>
      <div className="p-4 border-t border-primary/20">
        <div className="flex items-center gap-2">
          <Input
            placeholder="Type your message..."
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter") {
                handleSendMessage()
              }
            }}
          />
          <Button onClick={handleSendMessage}>Send</Button>
        </div>
      </div>
    </div>
  )
}

