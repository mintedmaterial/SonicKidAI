"use client"

import { Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { useState } from "react"

// Sample data - replace with your actual data
const generateData = (period: string) => {
  if (period === "day") {
    return Array.from({ length: 24 }, (_, i) => ({
      time: `${i}:00`,
      value: Math.floor(Math.random() * 100) + 50,
    }))
  } else if (period === "week") {
    return Array.from({ length: 7 }, (_, i) => ({
      time: ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"][i],
      value: Math.floor(Math.random() * 100) + 50,
    }))
  } else if (period === "month") {
    return Array.from({ length: 30 }, (_, i) => ({
      time: `${i + 1}`,
      value: Math.floor(Math.random() * 100) + 50,
    }))
  } else {
    return Array.from({ length: 12 }, (_, i) => ({
      time: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"][i],
      value: Math.floor(Math.random() * 100) + 50,
    }))
  }
}

export function StatsChart() {
  const [period, setPeriod] = useState("week")
  const [data, setData] = useState(() => generateData("week"))

  const handlePeriodChange = (newPeriod: string) => {
    setPeriod(newPeriod)
    setData(generateData(newPeriod))
  }

  return (
    <Card className="p-6 bg-background/50 backdrop-blur border border-primary/20 shadow-lg shadow-primary/5">
      <div className="mb-4 flex items-center justify-between">
        <h2 className="text-lg font-semibold">Agent Performance</h2>
        <div className="flex gap-2">
          <Button
            size="sm"
            variant={period === "day" ? "default" : "outline"}
            onClick={() => handlePeriodChange("day")}
            className="h-8"
          >
            Day
          </Button>
          <Button
            size="sm"
            variant={period === "week" ? "default" : "outline"}
            onClick={() => handlePeriodChange("week")}
            className="h-8"
          >
            Week
          </Button>
          <Button
            size="sm"
            variant={period === "month" ? "default" : "outline"}
            onClick={() => handlePeriodChange("month")}
            className="h-8"
          >
            Month
          </Button>
          <Button
            size="sm"
            variant={period === "year" ? "default" : "outline"}
            onClick={() => handlePeriodChange("year")}
            className="h-8"
          >
            Year
          </Button>
        </div>
      </div>
      <div className="h-[300px] w-full">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={data}>
            <XAxis dataKey="time" stroke="#888888" fontSize={12} tickLine={false} axisLine={false} />
            <YAxis
              stroke="#888888"
              fontSize={12}
              tickLine={false}
              axisLine={false}
              tickFormatter={(value) => `${value}`}
            />
            <Tooltip
              content={({ active, payload }) => {
                if (active && payload && payload.length) {
                  return (
                    <div className="rounded-lg border bg-background p-2 shadow-sm">
                      <div className="grid grid-cols-2 gap-2">
                        <div className="flex flex-col">
                          <span className="text-[0.70rem] uppercase text-muted-foreground">Value</span>
                          <span className="font-bold text-muted-foreground">{payload[0].value}</span>
                        </div>
                        <div className="flex flex-col">
                          <span className="text-[0.70rem] uppercase text-muted-foreground">Time</span>
                          <span className="font-bold">{payload[0].payload.time}</span>
                        </div>
                      </div>
                    </div>
                  )
                }
                return null
              }}
            />
            <Line
              type="monotone"
              dataKey="value"
              stroke="hsl(var(--primary))"
              strokeWidth={2}
              dot={false}
              activeDot={{ r: 6, fill: "hsl(var(--primary))" }}
            />
          </LineChart>
        </ResponsiveContainer>
      </div>
    </Card>
  )
}

