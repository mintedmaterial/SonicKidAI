"use client"

import { useEffect, useState } from "react"
import { useQuery } from "@tanstack/react-query"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { ExternalLink } from "lucide-react"

interface CryptoNewsProps {
  limit?: number
}

// Sample news data - replace with actual API response
const mockNews = [
  {
    id: "1",
    title: "Bitcoin Surges Past $67,000 as Institutional Adoption Grows",
    source: "CryptoPanic",
    url: "https://example.com/news/1",
    timestamp: new Date().toISOString(),
    sentiment: "positive",
  },
  {
    id: "2",
    title: "Ethereum Upgrade Delayed Until Q3, Developers Cite Security Concerns",
    source: "CoinDesk",
    url: "https://example.com/news/2",
    timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(),
    sentiment: "neutral",
  },
  {
    id: "3",
    title: "Solana Network Experiences Brief Outage, Quickly Recovers",
    source: "The Block",
    url: "https://example.com/news/3",
    timestamp: new Date(Date.now() - 5 * 60 * 60 * 1000).toISOString(),
    sentiment: "negative",
  },
  {
    id: "4",
    title: "Major Exchange Announces Support for New Layer 2 Solutions",
    source: "CryptoPanic",
    url: "https://example.com/news/4",
    timestamp: new Date(Date.now() - 8 * 60 * 60 * 1000).toISOString(),
    sentiment: "positive",
  },
  {
    id: "5",
    title: "Regulatory Clarity Coming for Crypto, Says SEC Commissioner",
    source: "CoinTelegraph",
    url: "https://example.com/news/5",
    timestamp: new Date(Date.now() - 12 * 60 * 60 * 1000).toISOString(),
    sentiment: "positive",
  },
  {
    id: "6",
    title: "NFT Market Shows Signs of Recovery After Months of Decline",
    source: "Decrypt",
    url: "https://example.com/news/6",
    timestamp: new Date(Date.now() - 16 * 60 * 60 * 1000).toISOString(),
    sentiment: "positive",
  },
  {
    id: "7",
    title: "DeFi Protocol Exploited for $3M, Team Working on Recovery",
    source: "CryptoPanic",
    url: "https://example.com/news/7",
    timestamp: new Date(Date.now() - 20 * 60 * 60 * 1000).toISOString(),
    sentiment: "negative",
  },
  {
    id: "8",
    title: "Central Bank Digital Currencies Could Coexist With Crypto, Study Finds",
    source: "CoinDesk",
    url: "https://example.com/news/8",
    timestamp: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString(),
    sentiment: "neutral",
  },
]

export function CryptoNews({ limit }: CryptoNewsProps) {
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  // In a real implementation, you would fetch data from CryptoPanic API
  const { data: news, isLoading } = useQuery({
    queryKey: ["crypto-news"],
    queryFn: async () => {
      // In a real implementation, you would fetch data from CryptoPanic
      // For example:
      // const response = await fetch(`https://cryptopanic.com/api/v1/posts/?auth_token=YOUR_TOKEN`);
      // const data = await response.json();
      // return data.results;

      // For now, return mock data
      return mockNews
    },
    refetchInterval: 300000, // Refresh every 5 minutes
    enabled: mounted,
  })

  const displayNews = limit ? news?.slice(0, limit) : news

  if (!mounted || isLoading) {
    return (
      <div className="animate-pulse space-y-4">
        {Array.from({ length: limit || 5 }).map((_, i) => (
          <div key={i} className="h-20 bg-muted rounded"></div>
        ))}
      </div>
    )
  }

  const getTimeAgo = (timestamp: string) => {
    const now = new Date()
    const past = new Date(timestamp)
    const diffMs = now.getTime() - past.getTime()
    const diffMins = Math.floor(diffMs / 60000)

    if (diffMins < 60) {
      return `${diffMins} min${diffMins !== 1 ? "s" : ""} ago`
    }

    const diffHours = Math.floor(diffMins / 60)
    if (diffHours < 24) {
      return `${diffHours} hour${diffHours !== 1 ? "s" : ""} ago`
    }

    const diffDays = Math.floor(diffHours / 24)
    return `${diffDays} day${diffDays !== 1 ? "s" : ""} ago`
  }

  const getSentimentColor = (sentiment: string) => {
    switch (sentiment) {
      case "positive":
        return "bg-green-500/10 text-green-500 hover:bg-green-500/20"
      case "negative":
        return "bg-red-500/10 text-red-500 hover:bg-red-500/20"
      default:
        return "bg-yellow-500/10 text-yellow-500 hover:bg-yellow-500/20"
    }
  }

  return (
    <div className="space-y-4">
      {displayNews?.map((item) => (
        <Card key={item.id} className="bg-background/70 border border-primary/10">
          <CardContent className="p-4">
            <div className="flex justify-between items-start gap-2">
              <h3 className="font-medium text-sm">{item.title}</h3>
              <a href={item.url} target="_blank" rel="noopener noreferrer" className="text-primary shrink-0">
                <ExternalLink className="h-4 w-4" />
              </a>
            </div>
            <div className="flex items-center justify-between mt-2">
              <div className="flex items-center gap-2">
                <span className="text-xs text-muted-foreground">{item.source}</span>
                <span className="text-xs text-muted-foreground">•</span>
                <span className="text-xs text-muted-foreground">{getTimeAgo(item.timestamp)}</span>
              </div>
              <Badge variant="outline" className={getSentimentColor(item.sentiment)}>
                {item.sentiment}
              </Badge>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}

