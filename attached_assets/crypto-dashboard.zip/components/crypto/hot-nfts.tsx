"use client"

import { useEffect, useState } from "react"
import { useQuery } from "@tanstack/react-query"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { ExternalLink } from "lucide-react"

// Sample NFT data - replace with actual API response
const mockNfts = [
  {
    id: "1",
    name: "Crypto Punk #3429",
    collection: "CryptoPunks",
    price: 45.5,
    currency: "ETH",
    image: "/placeholder.svg?height=100&width=100",
    url: "https://example.com/nft/1",
  },
  {
    id: "2",
    name: "Bored Ape #8765",
    collection: "BAYC",
    price: 78.2,
    currency: "ETH",
    image: "/placeholder.svg?height=100&width=100",
    url: "https://example.com/nft/2",
  },
  {
    id: "3",
    name: "Azuki #4532",
    collection: "Azuki",
    price: 12.8,
    currency: "ETH",
    image: "/placeholder.svg?height=100&width=100",
    url: "https://example.com/nft/3",
  },
  {
    id: "4",
    name: "Doodle #9876",
    collection: "Doodles",
    price: 8.5,
    currency: "ETH",
    image: "/placeholder.svg?height=100&width=100",
    url: "https://example.com/nft/4",
  },
  {
    id: "5",
    name: "CloneX #2345",
    collection: "CloneX",
    price: 6.2,
    currency: "ETH",
    image: "/placeholder.svg?height=100&width=100",
    url: "https://example.com/nft/5",
  },
  {
    id: "6",
    name: "Moonbird #7654",
    collection: "Moonbirds",
    price: 9.7,
    currency: "ETH",
    image: "/placeholder.svg?height=100&width=100",
    url: "https://example.com/nft/6",
  },
]

export function HotNfts() {
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  // In a real implementation, you would fetch data from PaintSwap API
  const { data: nfts, isLoading } = useQuery({
    queryKey: ["hot-nfts"],
    queryFn: async () => {
      // In a real implementation, you would fetch data from PaintSwap
      // For example:
      // const response = await fetch(`https://api.paintswap.finance/v2/nfts/trending`);
      // const data = await response.json();
      // return data.nfts;

      // For now, return mock data
      return mockNfts
    },
    refetchInterval: 300000, // Refresh every 5 minutes
    enabled: mounted,
  })

  if (!mounted || isLoading) {
    return (
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
        {Array.from({ length: 6 }).map((_, i) => (
          <div key={i} className="h-40 bg-muted rounded animate-pulse"></div>
        ))}
      </div>
    )
  }

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
      {nfts?.map((nft) => (
        <Card key={nft.id} className="overflow-hidden bg-background/70 border border-primary/10">
          <div className="aspect-square relative">
            <img src={nft.image || "/placeholder.svg"} alt={nft.name} className="w-full h-full object-cover" />
          </div>
          <CardContent className="p-4">
            <div className="flex justify-between items-start">
              <div>
                <h3 className="font-medium text-sm">{nft.name}</h3>
                <p className="text-xs text-muted-foreground">{nft.collection}</p>
              </div>
              <a href={nft.url} target="_blank" rel="noopener noreferrer" className="text-primary">
                <ExternalLink className="h-4 w-4" />
              </a>
            </div>
            <div className="mt-2 flex items-center justify-between">
              <Badge variant="outline" className="bg-primary/10 text-primary">
                {nft.price} {nft.currency}
              </Badge>
              <span className="text-xs text-muted-foreground">PaintSwap</span>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}

