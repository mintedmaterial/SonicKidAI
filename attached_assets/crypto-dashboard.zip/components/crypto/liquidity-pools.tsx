"use client"

import { useEffect, useState } from "react"
import { useQuery } from "@tanstack/react-query"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"

// Sample liquidity pool data - replace with actual API response
const mockPools = [
  {
    id: "1",
    name: "SONIC-USDC",
    tvl: 5432100,
    apy: 24.5,
    rewards: ["SONIC"],
    platform: "Equalizer",
  },
  {
    id: "2",
    name: "ETH-USDC",
    tvl: 87654321,
    apy: 12.3,
    rewards: ["ETH", "SONIC"],
    platform: "Equalizer",
  },
  {
    id: "3",
    name: "BTC-USDC",
    tvl: 123456789,
    apy: 8.7,
    rewards: ["BTC"],
    platform: "Equalizer",
  },
  {
    id: "4",
    name: "SOL-USDC",
    tvl: 23456789,
    apy: 18.2,
    rewards: ["SOL", "SONIC"],
    platform: "Equalizer",
  },
  {
    id: "5",
    name: "AAVE-USDC",
    tvl: 12345678,
    apy: 15.6,
    rewards: ["AAVE"],
    platform: "Equalizer",
  },
]

export function LiquidityPools() {
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  // In a real implementation, you would fetch data from Equalizer API
  const { data: pools, isLoading } = useQuery({
    queryKey: ["liquidity-pools"],
    queryFn: async () => {
      // In a real implementation, you would fetch data from Equalizer
      // For example:
      // const response = await fetch(`https://api.equalizer.exchange/pools`);
      // const data = await response.json();
      // return data.pools;

      // For now, return mock data
      return mockPools
    },
    refetchInterval: 60000, // Refresh every minute
    enabled: mounted,
  })

  if (!mounted || isLoading) {
    return (
      <div className="animate-pulse space-y-2">
        {Array.from({ length: 5 }).map((_, i) => (
          <div key={i} className="h-10 bg-muted rounded"></div>
        ))}
      </div>
    )
  }

  const formatTvl = (value: number) => {
    if (value >= 1000000) {
      return `$${(value / 1000000).toFixed(2)}M`
    }
    if (value >= 1000) {
      return `$${(value / 1000).toFixed(2)}K`
    }
    return `$${value.toFixed(2)}`
  }

  return (
    <div className="overflow-x-auto">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Pool</TableHead>
            <TableHead>TVL</TableHead>
            <TableHead>APY</TableHead>
            <TableHead>Rewards</TableHead>
            <TableHead>Platform</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {pools?.map((pool) => (
            <TableRow key={pool.id}>
              <TableCell className="font-medium">{pool.name}</TableCell>
              <TableCell>{formatTvl(pool.tvl)}</TableCell>
              <TableCell className="text-green-500">{pool.apy.toFixed(2)}%</TableCell>
              <TableCell>
                <div className="flex gap-1">
                  {pool.rewards.map((reward, i) => (
                    <Badge key={i} variant="outline" className="bg-primary/10 text-primary">
                      {reward}
                    </Badge>
                  ))}
                </div>
              </TableCell>
              <TableCell>{pool.platform}</TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  )
}

