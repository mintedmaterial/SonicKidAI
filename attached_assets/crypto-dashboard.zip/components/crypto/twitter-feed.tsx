"use client"

import { useEffect, useState } from "react"
import { useQuery } from "@tanstack/react-query"
import { Card, CardContent } from "@/components/ui/card"
import { Avatar } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { ExternalLink, Twitter } from "lucide-react"

interface TwitterFeedProps {
  limit?: number
}

// Sample Twitter data - replace with actual API response
const mockTweets = [
  {
    id: "1",
    content: "[Retweeted] @infinex_app",
    author: "michaelfkong",
    authorImage: "/placeholder.svg?height=40&width=40",
    timestamp: new Date().toISOString(),
    url: "https://twitter.com/michaelfkong/status/1903238812299563347",
    originalUrl: "https://twitter.com/infinex_app/status/1903220099307409562",
    isRetweet: true,
  },
  {
    id: "2",
    content: "Just announced: New partnership with @SonicSwap to enhance liquidity across multiple chains!",
    author: "crypto_influencer",
    authorImage: "/placeholder.svg?height=40&width=40",
    timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(),
    url: "https://twitter.com/crypto_influencer/status/1903238812299563348",
    isRetweet: false,
  },
  {
    id: "3",
    content: "Market analysis: BTC showing strong support at $65k level. Looking for a breakout above $70k this week.",
    author: "trader_expert",
    authorImage: "/placeholder.svg?height=40&width=40",
    timestamp: new Date(Date.now() - 5 * 60 * 60 * 1000).toISOString(),
    url: "https://twitter.com/trader_expert/status/1903238812299563349",
    isRetweet: false,
  },
  {
    id: "4",
    content: "[Retweeted] @defi_protocol",
    author: "crypto_news",
    authorImage: "/placeholder.svg?height=40&width=40",
    timestamp: new Date(Date.now() - 8 * 60 * 60 * 1000).toISOString(),
    url: "https://twitter.com/crypto_news/status/1903238812299563350",
    originalUrl: "https://twitter.com/defi_protocol/status/1903220099307409563",
    isRetweet: true,
  },
  {
    id: "5",
    content: "New regulatory framework for crypto being discussed in Congress today. This could be a game-changer!",
    author: "policy_watcher",
    authorImage: "/placeholder.svg?height=40&width=40",
    timestamp: new Date(Date.now() - 12 * 60 * 60 * 1000).toISOString(),
    url: "https://twitter.com/policy_watcher/status/1903238812299563351",
    isRetweet: false,
  },
  {
    id: "6",
    content: "Just published my analysis on the recent NFT market trends. Link in bio!",
    author: "nft_analyst",
    authorImage: "/placeholder.svg?height=40&width=40",
    timestamp: new Date(Date.now() - 16 * 60 * 60 * 1000).toISOString(),
    url: "https://twitter.com/nft_analyst/status/1903238812299563352",
    isRetweet: false,
  },
  {
    id: "7",
    content: "[Retweeted] @blockchain_dev",
    author: "tech_enthusiast",
    authorImage: "/placeholder.svg?height=40&width=40",
    timestamp: new Date(Date.now() - 20 * 60 * 60 * 1000).toISOString(),
    url: "https://twitter.com/tech_enthusiast/status/1903238812299563353",
    originalUrl: "https://twitter.com/blockchain_dev/status/1903220099307409564",
    isRetweet: true,
  },
]

export function TwitterFeed({ limit }: TwitterFeedProps) {
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  // In a real implementation, you would fetch data from the webhook
  const { data: tweets, isLoading } = useQuery({
    queryKey: ["twitter-feed"],
    queryFn: async () => {
      // In a real implementation, you would fetch data from the webhook
      // For example:
      // const response = await fetch(`https://discord.com/api/webhooks/1333605909141786694/2y82WGNQUnIpNuZ0f7f2qr06TN57WQKX8Peb-GLbpVN3_OAzMsANLf_rnDpocH0HlGOs`);
      // const data = await response.json();
      // return data.tweets;

      // For now, return mock data
      return mockTweets
    },
    refetchInterval: 60000, // Refresh every minute
    enabled: mounted,
  })

  const displayTweets = limit ? tweets?.slice(0, limit) : tweets

  if (!mounted || isLoading) {
    return (
      <div className="animate-pulse space-y-4">
        {Array.from({ length: limit || 5 }).map((_, i) => (
          <div key={i} className="h-20 bg-muted rounded"></div>
        ))}
      </div>
    )
  }

  const getTimeAgo = (timestamp: string) => {
    const now = new Date()
    const past = new Date(timestamp)
    const diffMs = now.getTime() - past.getTime()
    const diffMins = Math.floor(diffMs / 60000)

    if (diffMins < 60) {
      return `${diffMins} min${diffMins !== 1 ? "s" : ""} ago`
    }

    const diffHours = Math.floor(diffMins / 60)
    if (diffHours < 24) {
      return `${diffHours} hour${diffHours !== 1 ? "s" : ""} ago`
    }

    const diffDays = Math.floor(diffHours / 24)
    return `${diffDays} day${diffDays !== 1 ? "s" : ""} ago`
  }

  return (
    <div className="space-y-4">
      {displayTweets?.map((tweet) => (
        <Card key={tweet.id} className="bg-background/70 border border-primary/10">
          <CardContent className="p-4">
            <div className="flex items-start gap-3">
              <Avatar className="h-8 w-8">
                <img src={tweet.authorImage || "/placeholder.svg"} alt={tweet.author} />
              </Avatar>
              <div className="flex-1">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="font-medium text-sm">@{tweet.author}</span>
                    <span className="text-xs text-muted-foreground">•</span>
                    <span className="text-xs text-muted-foreground">{getTimeAgo(tweet.timestamp)}</span>
                  </div>
                  <a href={tweet.url} target="_blank" rel="noopener noreferrer" className="text-primary">
                    <ExternalLink className="h-4 w-4" />
                  </a>
                </div>
                <p className="text-sm mt-1">{tweet.content}</p>
                {tweet.isRetweet && (
                  <div className="mt-2">
                    <Badge variant="outline" className="bg-primary/10 text-primary flex items-center gap-1">
                      <Twitter className="h-3 w-3" />
                      <a href={tweet.originalUrl} target="_blank" rel="noopener noreferrer" className="hover:underline">
                        Original Tweet
                      </a>
                    </Badge>
                  </div>
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}

