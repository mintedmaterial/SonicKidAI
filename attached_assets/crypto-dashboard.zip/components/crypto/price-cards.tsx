"use client"

import type React from "react"

import { useEffect, useState } from "react"
import { Card } from "@/components/ui/card"
import { TrendingUp, TrendingDown, Bitcoin, Coins, Zap, AlertCircle } from "lucide-react"
import { useQuery } from "@tanstack/react-query"
import { Alert, AlertDescription } from "@/components/ui/alert"

// Webhook URLs for price data
const WEBHOOKS = {
  sonic:
    "https://discord.com/api/webhooks/1345565971477303386/ECVdbjtI_T-5wEjEqqIGp2RVIt1tEXv6nmsHhy-63z5-kGUVWuHe7jB-GxTza41Gnqln",
  aave: "https://discord.com/api/webhooks/1345566096610295848/M7EynPrtDO4nXDHrLpDF7L2Ug63cv5nqKiAaFHmrVnFpLtUngUxSC7aSzRUUg-nj_TGR",
  btc: "https://discord.com/api/webhooks/1352838334841360385/pJcsaGi7_KTiJJZyscJ8oOWyCmetLMdlMCoUsttViyvPGrwp8ElVJJkr2DGOl8KMzSUr",
  eth: "https://discord.com/api/webhooks/1352838441074819122/rknM5NG0z8FtgluoUA298fkknT5B55CRihtOIF-Siol2skwCBbzQRHSwJT9BKrdetOyL",
  sol: "https://discord.com/api/webhooks/1345566262364868699/erRl05A6XEkKyl5PyoH6bPAIZ2C22e9xNSqeutmuPBVA_BbNlwwI0scsZG5UT06kFZkp",
}

// Sample data structure - replace with actual API response structure
interface PriceData {
  symbol: string
  name: string
  price: number
  change24h: number
  volume24h: number
  marketCap: number
  icon: React.ReactNode
}

// Mock data - replace with actual API calls
const mockPriceData: Record<string, PriceData> = {
  btc: {
    symbol: "BTC",
    name: "Bitcoin",
    price: 67432.51,
    change24h: 2.34,
    volume24h: 28765432123,
    marketCap: 1324567890123,
    icon: <Bitcoin className="h-6 w-6" />,
  },
  eth: {
    symbol: "ETH",
    name: "Ethereum",
    price: 3521.87,
    change24h: -1.23,
    volume24h: 15432678901,
    marketCap: 423456789012,
    icon: <Coins className="h-6 w-6" />,
  },
  sol: {
    symbol: "SOL",
    name: "Solana",
    price: 143.21,
    change24h: 5.67,
    volume24h: 5678901234,
    marketCap: 56789012345,
    icon: <Zap className="h-6 w-6" />,
  },
  sonic: {
    symbol: "SONIC",
    name: "Sonic",
    price: 0.0432,
    change24h: 12.34,
    volume24h: 1234567,
    marketCap: 43210987,
    icon: <Zap className="h-6 w-6" />,
  },
  aave: {
    symbol: "AAVE",
    name: "Aave",
    price: 92.76,
    change24h: -0.87,
    volume24h: 234567890,
    marketCap: 1234567890,
    icon: <Coins className="h-6 w-6" />,
  },
}

export function PriceCards() {
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  // In a real implementation, you would fetch data from the webhooks
  // For now, we'll use mock data
  const {
    data: priceData = mockPriceData,
    isLoading,
    error,
  } = useQuery({
    queryKey: ["crypto-prices"],
    queryFn: async () => {
      try {
        // In a real implementation, you would fetch data from the webhooks
        // For example:
        // const responses = await Promise.all(
        //   Object.entries(WEBHOOKS).map(async ([key, url]) => {
        //     const response = await fetch(url);
        //     if (!response.ok) {
        //       throw new Error(`Failed to fetch ${key} data: ${response.status}`);
        //     }
        //     const data = await response.json();
        //     return [key, data];
        //   })
        // );
        // return Object.fromEntries(responses);

        // For now, return mock data
        return mockPriceData
      } catch (err) {
        console.error("Error fetching price data:", err)
        throw err // Re-throw to let React Query handle it
      }
    },
    refetchInterval: 60000, // Refresh every minute
    enabled: mounted,
    // Add specific error handling for this query
    onError: (err) => {
      console.error("Price cards query error:", err)
    },
  })

  if (!mounted) {
    return (
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
        {Array.from({ length: 5 }).map((_, i) => (
          <Card key={i} className="p-4 bg-background/50 backdrop-blur animate-pulse h-32">
            <div className="h-full flex items-center justify-center">
              <div className="h-4 w-20 bg-muted rounded"></div>
            </div>
          </Card>
        ))}
      </div>
    )
  }

  if (error) {
    return (
      <Alert variant="destructive" className="mb-4">
        <AlertCircle className="h-4 w-4" />
        <AlertDescription>Failed to load price data. Please try again later.</AlertDescription>
      </Alert>
    )
  }

  if (isLoading) {
    return (
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
        {Array.from({ length: 5 }).map((_, i) => (
          <Card key={i} className="p-4 bg-background/50 backdrop-blur animate-pulse h-32">
            <div className="h-full flex items-center justify-center">
              <div className="h-4 w-20 bg-muted rounded"></div>
            </div>
          </Card>
        ))}
      </div>
    )
  }

  return (
    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
      {Object.entries(priceData).map(([key, data]) => (
        <Card
          key={key}
          className="p-4 bg-background/50 backdrop-blur border border-primary/20 shadow-lg shadow-primary/5"
        >
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-2">
              <div className="text-primary">{data.icon}</div>
              <div>
                <h3 className="font-bold">{data.symbol}</h3>
                <p className="text-xs text-muted-foreground">{data.name}</p>
              </div>
            </div>
          </div>
          <div className="mt-2">
            <p className="text-xl font-bold">
              ${data.price.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 8 })}
            </p>
            <div className={`flex items-center gap-1 mt-1 ${data.change24h >= 0 ? "text-green-500" : "text-red-500"}`}>
              {data.change24h >= 0 ? <TrendingUp className="h-3 w-3" /> : <TrendingDown className="h-3 w-3" />}
              <span className="text-sm">
                {data.change24h >= 0 ? "+" : ""}
                {data.change24h.toFixed(2)}%
              </span>
            </div>
          </div>
        </Card>
      ))}
    </div>
  )
}

