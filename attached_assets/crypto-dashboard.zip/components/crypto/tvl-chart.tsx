"use client"

import { useEffect, useState } from "react"
import { useQuery } from "@tanstack/react-query"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Area, AreaChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts"
import { AlertCircle } from "lucide-react"
import { Alert, AlertDescription } from "@/components/ui/alert"

interface TvlChartProps {
  height?: number
}

// Sample TVL data - replace with actual API response
const mockTvlData = {
  daily: Array.from({ length: 30 }, (_, i) => ({
    date: new Date(Date.now() - (29 - i) * 24 * 60 * 60 * 1000).toLocaleDateString(),
    tvl: 500000000 + Math.random() * 100000000,
  })),
  weekly: Array.from({ length: 12 }, (_, i) => ({
    date: `Week ${i + 1}`,
    tvl: 500000000 + Math.random() * 100000000,
  })),
  monthly: Array.from({ length: 12 }, (_, i) => ({
    date: new Date(2023, i, 1).toLocaleDateString("en-US", { month: "short" }),
    tvl: 500000000 + Math.random() * 100000000,
  })),
}

export function TvlChart({ height = 300 }: TvlChartProps) {
  const [mounted, setMounted] = useState(false)
  const [timeframe, setTimeframe] = useState<"daily" | "weekly" | "monthly">("daily")

  useEffect(() => {
    setMounted(true)
  }, [])

  // In a real implementation, you would fetch data from DeFiLlama API
  const {
    data: tvlData,
    isLoading,
    error,
  } = useQuery({
    queryKey: ["tvl-data", timeframe],
    queryFn: async () => {
      try {
        // In a real implementation, you would fetch data from DeFiLlama
        // For example:
        // const response = await fetch(`https://api.defillama.com/charts/...`);
        // if (!response.ok) {
        //   throw new Error(`Failed to fetch TVL data: ${response.status}`);
        // }
        // const data = await response.json();
        // return data;

        // For now, return mock data
        return mockTvlData[timeframe]
      } catch (err) {
        console.error("Error fetching TVL data:", err)
        throw err // Re-throw to let React Query handle it
      }
    },
    refetchInterval: 300000, // Refresh every 5 minutes
    enabled: mounted,
    onError: (err) => {
      console.error("TVL chart query error:", err)
    },
  })

  if (!mounted) {
    return (
      <div className="flex items-center justify-center" style={{ height }}>
        <div className="animate-pulse h-4 w-32 bg-muted rounded"></div>
      </div>
    )
  }

  if (error) {
    return (
      <Alert variant="destructive">
        <AlertCircle className="h-4 w-4" />
        <AlertDescription>Failed to load TVL data. Please try again later.</AlertDescription>
      </Alert>
    )
  }

  if (isLoading) {
    return (
      <div className="flex items-center justify-center" style={{ height }}>
        <div className="animate-pulse h-4 w-32 bg-muted rounded"></div>
      </div>
    )
  }

  const formatTvl = (value: number) => {
    if (value >= 1000000000) {
      return `$${(value / 1000000000).toFixed(2)}B`
    }
    if (value >= 1000000) {
      return `$${(value / 1000000).toFixed(2)}M`
    }
    return `$${(value / 1000).toFixed(2)}K`
  }

  return (
    <div>
      <div className="flex justify-end mb-4 gap-2">
        <Button size="sm" variant={timeframe === "daily" ? "default" : "outline"} onClick={() => setTimeframe("daily")}>
          Daily
        </Button>
        <Button
          size="sm"
          variant={timeframe === "weekly" ? "default" : "outline"}
          onClick={() => setTimeframe("weekly")}
        >
          Weekly
        </Button>
        <Button
          size="sm"
          variant={timeframe === "monthly" ? "default" : "outline"}
          onClick={() => setTimeframe("monthly")}
        >
          Monthly
        </Button>
      </div>
      <div style={{ height }}>
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={tvlData}>
            <defs>
              <linearGradient id="tvlGradient" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.8} />
                <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0} />
              </linearGradient>
            </defs>
            <XAxis dataKey="date" stroke="#888888" fontSize={12} tickLine={false} axisLine={false} />
            <YAxis stroke="#888888" fontSize={12} tickLine={false} axisLine={false} tickFormatter={formatTvl} />
            <Tooltip
              content={({ active, payload }) => {
                if (active && payload && payload.length) {
                  return (
                    <Card className="p-2 border border-primary/20 bg-background/90 backdrop-blur">
                      <div className="grid grid-cols-2 gap-2">
                        <div className="flex flex-col">
                          <span className="text-[0.70rem] uppercase text-muted-foreground">Date</span>
                          <span className="font-bold">{payload[0].payload.date}</span>
                        </div>
                        <div className="flex flex-col">
                          <span className="text-[0.70rem] uppercase text-muted-foreground">TVL</span>
                          <span className="font-bold text-primary">{formatTvl(payload[0].value as number)}</span>
                        </div>
                      </div>
                    </Card>
                  )
                }
                return null
              }}
            />
            <Area type="monotone" dataKey="tvl" stroke="hsl(var(--primary))" fillOpacity={1} fill="url(#tvlGradient)" />
          </AreaChart>
        </ResponsiveContainer>
      </div>
    </div>
  )
}

