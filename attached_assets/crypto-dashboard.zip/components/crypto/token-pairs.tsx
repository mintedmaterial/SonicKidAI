"use client"

import { useEffect, useState } from "react"
import { useQuery } from "@tanstack/react-query"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { TrendingUp, TrendingDown } from "lucide-react"
import { Badge } from "@/components/ui/badge"

interface TokenPairsProps {
  limit?: number
}

// Sample token pair data - replace with actual API response
const mockPairs = [
  {
    id: "1",
    name: "SONIC/USDC",
    price: 0.0432,
    change24h: 12.34,
    volume24h: 1234567,
    liquidity: 5432100,
    exchange: "SonicSwap",
  },
  {
    id: "2",
    name: "ETH/USDC",
    price: 3521.87,
    change24h: -1.23,
    volume24h: 15432678,
    liquidity: 87654321,
    exchange: "DexScreener",
  },
  {
    id: "3",
    name: "BTC/USDC",
    price: 67432.51,
    change24h: 2.34,
    volume24h: 28765432,
    liquidity: 123456789,
    exchange: "DexScreener",
  },
  {
    id: "4",
    name: "SOL/USDC",
    price: 143.21,
    change24h: 5.67,
    volume24h: 5678901,
    liquidity: 23456789,
    exchange: "DexScreener",
  },
  {
    id: "5",
    name: "AAVE/USDC",
    price: 92.76,
    change24h: -0.87,
    volume24h: 2345678,
    liquidity: 12345678,
    exchange: "DexScreener",
  },
  {
    id: "6",
    name: "MATIC/USDC",
    price: 0.65,
    change24h: 3.45,
    volume24h: 1234567,
    liquidity: 9876543,
    exchange: "DexScreener",
  },
  {
    id: "7",
    name: "AVAX/USDC",
    price: 34.56,
    change24h: -2.34,
    volume24h: 3456789,
    liquidity: 23456789,
    exchange: "DexScreener",
  },
  {
    id: "8",
    name: "LINK/USDC",
    price: 17.89,
    change24h: 1.23,
    volume24h: 2345678,
    liquidity: 12345678,
    exchange: "DexScreener",
  },
]

export function TokenPairs({ limit }: TokenPairsProps) {
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  // In a real implementation, you would fetch data from DexScreener API
  const { data: pairs, isLoading } = useQuery({
    queryKey: ["token-pairs"],
    queryFn: async () => {
      // In a real implementation, you would fetch data from DexScreener
      // For example:
      // const response = await fetch(`https://api.dexscreener.com/latest/dex/pairs/...`);
      // const data = await response.json();
      // return data.pairs;

      // For now, return mock data
      return mockPairs
    },
    refetchInterval: 60000, // Refresh every minute
    enabled: mounted,
  })

  const displayPairs = limit ? pairs?.slice(0, limit) : pairs

  if (!mounted || isLoading) {
    return (
      <div className="animate-pulse space-y-2">
        {Array.from({ length: limit || 5 }).map((_, i) => (
          <div key={i} className="h-10 bg-muted rounded"></div>
        ))}
      </div>
    )
  }

  const formatNumber = (value: number) => {
    if (value >= 1000000) {
      return `$${(value / 1000000).toFixed(2)}M`
    }
    if (value >= 1000) {
      return `$${(value / 1000).toFixed(2)}K`
    }
    return `$${value.toFixed(2)}`
  }

  return (
    <div className="overflow-x-auto">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Pair</TableHead>
            <TableHead>Price</TableHead>
            <TableHead>24h</TableHead>
            <TableHead>Volume</TableHead>
            <TableHead>Liquidity</TableHead>
            <TableHead>Exchange</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {displayPairs?.map((pair) => (
            <TableRow key={pair.id}>
              <TableCell className="font-medium">{pair.name}</TableCell>
              <TableCell>
                ${pair.price.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 8 })}
              </TableCell>
              <TableCell>
                <div className={`flex items-center gap-1 ${pair.change24h >= 0 ? "text-green-500" : "text-red-500"}`}>
                  {pair.change24h >= 0 ? <TrendingUp className="h-3 w-3" /> : <TrendingDown className="h-3 w-3" />}
                  <span>
                    {pair.change24h >= 0 ? "+" : ""}
                    {pair.change24h.toFixed(2)}%
                  </span>
                </div>
              </TableCell>
              <TableCell>{formatNumber(pair.volume24h)}</TableCell>
              <TableCell>{formatNumber(pair.liquidity)}</TableCell>
              <TableCell>
                <Badge variant="outline" className="bg-primary/10 text-primary">
                  {pair.exchange}
                </Badge>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  )
}

