"use client"

import { useState, useCallback, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import {
  LayoutDashboard,
  MessageSquare,
  BarChart3,
  Settings,
  Users,
  Database,
  Bot,
  Menu,
  X,
  Home,
  Coins,
} from "lucide-react"
import { cn } from "@/lib/utils"
import Image from "next/image"

export function Sidebar() {
  const [isOpen, setIsOpen] = useState(false)
  const [currentPath, setCurrentPath] = useState("")

  // Update current path when component mounts or path changes
  useEffect(() => {
    setCurrentPath(window.location.pathname)

    // Listen for path changes
    const handlePathChange = () => {
      setCurrentPath(window.location.pathname)
    }

    window.addEventListener("popstate", handlePathChange)
    return () => window.removeEventListener("popstate", handlePathChange)
  }, [])

  // Use useCallback to memoize the toggle function
  const toggleSidebar = useCallback(() => {
    setIsOpen((prev) => !prev)
  }, [])

  // Handle navigation without using Wouter
  const handleNavigation = useCallback((path: string) => {
    window.history.pushState({}, "", path)
    setCurrentPath(path)
    // Close sidebar on mobile after navigation
    if (window.innerWidth < 1024) {
      setIsOpen(false)
    }
  }, [])

  const navItems = [
    { href: "/", icon: Home, label: "Home" },
    { href: "/dashboard", icon: LayoutDashboard, label: "Dashboard" },
    { href: "/crypto", icon: Coins, label: "Crypto" },
    { href: "/chat", icon: MessageSquare, label: "Chat" },
    { href: "/analytics", icon: BarChart3, label: "Analytics" },
    { href: "/agents", icon: Bot, label: "Agents" },
    { href: "/users", icon: Users, label: "Users" },
    { href: "/database", icon: Database, label: "Database" },
    { href: "/settings", icon: Settings, label: "Settings" },
  ]

  return (
    <>
      {/* Mobile menu button */}
      <Button variant="ghost" size="icon" className="fixed top-4 left-4 z-50 lg:hidden" onClick={toggleSidebar}>
        {isOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
      </Button>

      {/* Sidebar */}
      <aside
        className={cn(
          "fixed inset-y-0 left-0 z-40 w-64 bg-background/80 backdrop-blur-md border-r border-primary/20 transition-transform duration-300 ease-in-out lg:translate-x-0",
          isOpen ? "translate-x-0" : "-translate-x-full",
        )}
      >
        {/* Logo and brand header with background image */}
        <div className="relative h-24 border-b border-primary/20 overflow-hidden">
          {/* Background image */}
          <div className="absolute inset-0 opacity-30">
            <Image
              src="/images/market-visualization.png"
              alt="Market visualization"
              fill
              className="object-cover"
              priority
            />
          </div>

          {/* Logo and text overlay */}
          <div className="relative z-10 h-full flex items-center px-6">
            <div className="h-10 w-10 rounded-full bg-primary/20 flex items-center justify-center mr-3">
              <Bot className="h-6 w-6 text-primary" />
            </div>
            <div>
              <h1 className="font-bold text-xl text-foreground">SonicKid AI</h1>
              <p className="text-xs text-muted-foreground">Crypto Intelligence</p>
            </div>
          </div>
        </div>

        <div className="px-4 py-4">
          <Input placeholder="Search" className="bg-background/50" />
        </div>
        <nav className="space-y-1 px-2">
          {navItems.map((item) => (
            <div key={item.href}>
              <Button
                variant={currentPath === item.href ? "default" : "ghost"}
                className={cn(
                  "w-full justify-start gap-2",
                  currentPath === item.href ? "bg-primary text-primary-foreground" : "",
                )}
                onClick={() => handleNavigation(item.href)}
              >
                <item.icon className="h-4 w-4" />
                {item.label}
              </Button>
            </div>
          ))}
        </nav>
      </aside>
    </>
  )
}

