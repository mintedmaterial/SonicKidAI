import { Avatar } from "@/components/ui/avatar"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { MoreHorizontal, Bot, Brain, Zap } from "lucide-react"

// Sample data - replace with your actual data
const agents = [
  {
    name: "Anthropic Claude",
    type: "anthropic",
    status: "active",
    requests: 1243,
    responseTime: "0.8s",
    accuracy: "94%",
    lastActive: "2 min ago",
    load: "low",
  },
  {
    name: "Hyperbolic Agent",
    type: "hyperbolic",
    status: "active",
    requests: 876,
    responseTime: "1.2s",
    accuracy: "91%",
    lastActive: "5 min ago",
    load: "medium",
  },
  {
    name: "GPT-4 Agent",
    type: "openai",
    status: "inactive",
    requests: 2145,
    responseTime: "0.6s",
    accuracy: "96%",
    lastActive: "1 hour ago",
    load: "high",
  },
]

export function AgentTable() {
  return (
    <Table>
      <TableHeader>
        <TableRow>
          <TableHead>Agent</TableHead>
          <TableHead>Status</TableHead>
          <TableHead>Requests</TableHead>
          <TableHead>Response Time</TableHead>
          <TableHead>Accuracy</TableHead>
          <TableHead>Last Active</TableHead>
          <TableHead>Load</TableHead>
          <TableHead></TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        {agents.map((agent) => (
          <TableRow key={agent.name}>
            <TableCell className="font-medium">
              <div className="flex items-center gap-2">
                <Avatar className="h-8 w-8 bg-primary/10">
                  {agent.type === "anthropic" ? (
                    <Brain className="h-4 w-4 text-primary" />
                  ) : agent.type === "hyperbolic" ? (
                    <Zap className="h-4 w-4 text-primary" />
                  ) : (
                    <Bot className="h-4 w-4 text-primary" />
                  )}
                </Avatar>
                <div>
                  <div className="font-medium">{agent.name}</div>
                  <div className="text-xs text-muted-foreground capitalize">{agent.type}</div>
                </div>
              </div>
            </TableCell>
            <TableCell>
              <Badge
                variant="outline"
                className={`
                  ${
                    agent.status === "active"
                      ? "bg-green-500/10 text-green-500 hover:bg-green-500/20 hover:text-green-500"
                      : "bg-red-500/10 text-red-500 hover:bg-red-500/20 hover:text-red-500"
                  }
                `}
              >
                {agent.status}
              </Badge>
            </TableCell>
            <TableCell>{agent.requests.toLocaleString()}</TableCell>
            <TableCell>{agent.responseTime}</TableCell>
            <TableCell>{agent.accuracy}</TableCell>
            <TableCell>{agent.lastActive}</TableCell>
            <TableCell>
              <div className="flex gap-1">
                {Array.from({ length: 3 }).map((_, i) => (
                  <div
                    key={i}
                    className={`h-1.5 w-3 rounded-full ${
                      i < (agent.load === "high" ? 3 : agent.load === "medium" ? 2 : 1) ? "bg-primary" : "bg-muted"
                    }`}
                  />
                ))}
              </div>
            </TableCell>
            <TableCell>
              <MoreHorizontal className="h-4 w-4 text-muted-foreground" />
            </TableCell>
          </TableRow>
        ))}
      </TableBody>
    </Table>
  )
}

