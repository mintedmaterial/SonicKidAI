"use client"

import { useEffect, useState } from "react"
import { useQuery } from "@tanstack/react-query"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { ScrollArea } from "@/components/ui/scroll-area"

// This is a placeholder type that matches the structure from the original code
// Replace with your actual type if different
type DashboardPost = {
  id: number
  title?: string
  type: string
  content: string
  createdAt: string
  metadata?: {
    sentiment?: string
    confidence?: number
    [key: string]: any
  }
}

export function DashboardFeed() {
  const [mounted, setMounted] = useState(false)

  // Only run queries after component has mounted
  useEffect(() => {
    setMounted(true)
  }, [])

  const {
    data: posts,
    isLoading,
    error,
  } = useQuery<DashboardPost[]>({
    queryKey: ["/api/dashboard/posts"],
    // Refresh every 30 seconds
    refetchInterval: 30000,
    // Keep previous data while fetching new data
    keepPreviousData: true,
    // Refresh when window regains focus
    refetchOnWindowFocus: true,
    // Disable suspense to prevent insertion effect issues
    suspense: false,
    // Disable error boundary to prevent insertion effect issues
    useErrorBoundary: false,
    // Only run query after component has mounted
    enabled: mounted,
  })

  if (!mounted || isLoading) {
    return (
      <Card className="w-full">
        <CardHeader>
          <CardTitle>Agent Activity</CardTitle>
          <CardDescription>Loading latest updates...</CardDescription>
        </CardHeader>
      </Card>
    )
  }

  if (error) {
    return (
      <Card className="w-full">
        <CardHeader>
          <CardTitle>Agent Activity</CardTitle>
          <CardDescription>Error loading updates</CardDescription>
        </CardHeader>
      </Card>
    )
  }

  return (
    <Card className="w-full bg-background/50 backdrop-blur border border-primary/20 shadow-lg shadow-primary/5">
      <CardHeader>
        <CardTitle>Agent Activity</CardTitle>
        <CardDescription>Recent updates from agents</CardDescription>
      </CardHeader>
      <CardContent>
        <ScrollArea className="h-[500px] pr-4">
          {posts?.map((post) => (
            <Card key={post.id} className="mb-4 bg-background/70 border border-primary/10">
              <CardHeader className="py-3">
                <CardTitle className="text-sm font-medium">{post.title || post.type}</CardTitle>
                <CardDescription>{new Date(post.createdAt).toLocaleString()}</CardDescription>
              </CardHeader>
              <CardContent className="py-2">
                <p className="text-sm">{post.content}</p>
                {post.type === "tweet" && post.metadata && (
                  <div className="mt-2 text-sm text-muted-foreground">
                    Sentiment: {post.metadata.sentiment} (Confidence: {post.metadata.confidence}%)
                  </div>
                )}
              </CardContent>
            </Card>
          ))}
        </ScrollArea>
      </CardContent>
    </Card>
  )
}

